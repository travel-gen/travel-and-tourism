import React, { useState } from "react";
import "./App.css";

function App() {
  const [formData, setFormData] = useState({
    destination: "",
    budget: "",
    days: "",
    companions: ""
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form Data Submitted: ", formData);
  };

  return (
    <div className="container">
      <h1>✈️ Plan Your Trip 🌍</h1>
      <form onSubmit={handleSubmit}>
        <div className="input-group">
          <label>Where are you planning to go? 🏖️</label>
          <input
            type="text"
            name="destination"
            value={formData.destination}
            onChange={handleChange}
            placeholder="Enter your destination"
            required
          />
        </div>

        <div className="input-group">
          <label>Select your budget type: 💰</label>
          <div className="budget-cards">
            <div
              className={`card ${formData.budget === "basic" ? "selected" : ""}`}
              onClick={() => setFormData({ ...formData, budget: "basic" })}
            >
              <h3>Basic</h3>
              <p>For budget-friendly trips</p>
            </div>
            <div
              className={`card ${formData.budget === "moderate" ? "selected" : ""}`}
              onClick={() => setFormData({ ...formData, budget: "moderate" })}
            >
              <h3>Moderate</h3>
              <p>Comfortable and affordable</p>
            </div>
            <div
              className={`card ${formData.budget === "luxury" ? "selected" : ""}`}
              onClick={() => setFormData({ ...formData, budget: "luxury" })}
            >
              <h3>Luxury</h3>
              <p>For lavish and premium experiences</p>
            </div>
          </div>
        </div>

        <div className="input-group">
          <label>How many days are you planning to stay? 📅</label>
          <input
            type="number"
            name="days"
            value={formData.days}
            onChange={handleChange}
            placeholder="Enter number of days"
            required
          />
        </div>

        <div className="input-group">
          <label>Who are you traveling with? 🧳</label>
          <input
            type="text"
            name="companions"
            value={formData.companions}
            onChange={handleChange}
            placeholder="e.g., family, friends, solo"
            required
          />
        </div>

        <button type="submit">🚀 Plan My Trip</button>
      </form>
    </div>
  );
}

export default App;
